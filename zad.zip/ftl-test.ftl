#output0 /1
and1 /1
and1->output0 /1
and2 /1
nor1 /1